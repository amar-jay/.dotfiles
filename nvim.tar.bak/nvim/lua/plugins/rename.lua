-- incremental rename
return {
  "smjonas/inc-rename.nvim",
  cmd = "IncRename",
  config = {},
}
