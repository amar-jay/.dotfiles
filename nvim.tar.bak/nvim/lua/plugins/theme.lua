-- will set up my theme later using amarjay/*

return {
  {
    "craftzdog/solarized-osaka.nvim",
    opts = {
      lazy = true,
      priority = 1000,
      transparent = true,
    }
  },
}
