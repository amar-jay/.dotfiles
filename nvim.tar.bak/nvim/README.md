<h2 align="center"> MY NEOVIM CONFIG</h2>

This is built with __Neovim, LazyVim, Mason__, and other awesome plugins.

![screenshot](./ace-screenshot.png)