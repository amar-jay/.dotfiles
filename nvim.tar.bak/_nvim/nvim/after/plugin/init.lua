-- The plugin configuration used
-- NOTE: SHOULD MATCH PLUGIN USE IN INIT.LUA FILE
--require("amarjay_after")
require("kickstart_after")
