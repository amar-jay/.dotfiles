require("amarjay_after.colorscheme")
require("amarjay_after.cmp")
require("amarjay_after.colorizer")
require("amarjay_after.lspkind")
require("amarjay_after.lspconfig")
require("amarjay_after.snippets")
require("amarjay_after.telescope")
require("amarjay_after.formatting")
require("amarjay_after.other_keymaps")
--require("amarjay_after.statusbar")
require("amarjay_after.telescope")
--[[
colorsheme.lua  lsp-colors.lua  lspkind.lua        snippets.lua   telescope.lua           treesitter.lua
colorizer.lua  formatting.lua  lspconfig.lua   other_keymaps.lua  statusbar.lua  treesitter-context.lua  web-devicons.lua
--]]
